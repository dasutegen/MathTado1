@echo off
start "Math Tado" "%~dp0index.html"
